       
Tropical2 Sky Map by Alex "alX" Peterson
____________
 
  Unzip the .tga and .bmp files in this archive to your Half-Life/valve/gfx/env directory
  Environment map name: tropical2
____________

http://www.planethalflife.com/crinity

crinity@email.com